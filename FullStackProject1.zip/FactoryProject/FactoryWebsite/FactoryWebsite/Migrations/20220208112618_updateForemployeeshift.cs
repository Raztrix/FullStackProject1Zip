﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace FactoryWebsite.Migrations
{
    public partial class updateForemployeeshift : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
