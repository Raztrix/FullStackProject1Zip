﻿namespace FactoryWebsite.Models
{
    public class Token
    {
       public string token { get; set; } = string.Empty;
    }
}
